/**
 * @brief It implements the game interface and all the associated callbacks
 * for each command
 *
 * @file game.c
 * @author Profesores PPROG
 * @version 1.0
 * @date 13-01-2015
 * @copyright GNU Public License
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>
#include "game.h"
#include "game_reader.h"


#define N_CALLBACK 11

struct _Game{ 
  Player *players;    /* !<  Structure of the Player  */
  Object *objects[MAX_OBJECTS];    /*!< Structure of the Object */
  Die *dice;          /*!< Structure of the Die */
  Space* spaces[MAX_SPACES + 1];    /*!< Array of structures of Space */
  Command *cmd;    /*!< Last command */
  int last_roll;
  Link *links[MAX_LINK +1];
  char description[WORD_SIZE+1];
};

/**
* Define the function type for the callbacks
*/
typedef void (*callback_fn)(Game* game);


/**
* List of callbacks for each command in the game
*/
void game_callback_unknown(Game* game);
void game_callback_exit(Game* game);
void game_callback_next(Game* game);
void game_callback_back(Game* game);
void game_callback_left(Game* game);
void game_callback_right(Game* game);
void game_callback_roll(Game* game);
void game_callback_pickup(Game* game);
void game_callback_drop(Game* game);
void game_callback_move(Game* game);
void game_callback_inspect(Game* game);
/* */

static callback_fn game_callback_fn_list[N_CALLBACK]={
  game_callback_unknown,
  game_callback_exit,
  game_callback_next,
  game_callback_back,
  game_callback_left,
  game_callback_right,
  game_callback_roll,
  game_callback_pickup,
  game_callback_drop,
  game_callback_move,
  game_callback_inspect
  };


/**
*      @brief Creates the game
*                              
*      It creates the game, load the spaces to NULL, creates the player
*           and the array of objects and initializes and initializes their Id 
*                     to the local variable i last_cmd to no command                     
*                                      
*      param: structure Game from file game.h
*
*      @alexConache & CiroAlonso                       
*/


STATUS game_create(Game** game) {
  int i = 0;

  *game = (Game*)malloc(sizeof(Game));

  for (i = 0; i < MAX_SPACES; i++) {
    (*game)->spaces[i] = NULL;
  }

  (*game)->players = player_create();
  game_set_player_location((*game),NO_ID);

  for(i=0; i<MAX_OBJECTS; i++){
    (*game)->objects[i]= NULL;
  }

  for(i=0; i<MAX_LINK; i++){
    (*game)->links[i]= NULL;
  }

  (*game)->dice = die_create();
  (*game)->cmd = command_create();
  (*game)->description[0] = '\0';

  return OK;
}

/**
*      @brief Creates the game from file
*                              
*      It creates the game, load the spaces and set the                                 
*             locations of the player and the object                         
*                                      
*      param: structure Game from file game.h
*      param: char filename, necessary to load spaces  
*      @alexConache & CiroAlonso                       
*/

STATUS game_create_from_file(Game** game, char* filename) {
  
  if (game_create(game) == ERROR){
    return ERROR;
  }
  if (game_reader_load_spaces((*game), filename) == ERROR){
    return ERROR;
  } 
  if(game_reader_load_objects((*game), filename) == ERROR){
    return ERROR;
  }
  if(game_reader_load_links((*game), filename) == ERROR){
    return ERROR;
  }
  game_set_player_location((*game), game_get_space_id_at((*game), 0));
  
  return OK;
}



/**
*     @brief Destroys de memory peviously called   

*     Destroys the memroy created for each space, the player                                
*                         and the object             
*     param: structure Game from file game.h                                
*     @alexConache & CiroAlonso                                 
*/

STATUS game_destroy(Game* game) {
  int i = 0;

  for (i = 0; (i < MAX_SPACES) && (game->spaces[i] != NULL); i++) {
    space_destroy(game->spaces[i]);
    game->spaces[i] = NULL;
  }

  player_destroy(game->players);
  
  die_destroy(game->dice);

  for(i=0; (i<MAX_OBJECTS) && (game->objects[i] != NULL);i++){
    object_destroy(game->objects[i]);
  }

  for(i=0; (i<MAX_LINK) && (game->links[i] != NULL);i++){
    link_destroy(game->links[i]);
  }
  
  command_destroy(game->cmd);
  free(game);
  return OK;
}




/**
*      @brief Adds space to the game
*                                   
*      param: structure Game from file game.h
*      param: struct Space from file space.c  
*      @alexConache & CiroAlonso                       
*/

STATUS game_add_space(Game* game, Space* space) {
  int i = 0;

  if (space == NULL) {
    return ERROR;
  }

  while ( (i < MAX_SPACES) && (game->spaces[i] != NULL)){
    i++;
  }

  if (i >= MAX_SPACES) {
    return ERROR;
  }

  game->spaces[i] = space;

  return OK;
}



/**
*      @brief Returns the id of the space
*                              
*      Checks for errors, if not returns the id of the space of the game
*                 thanks to the finction space_get_id
*      param: structure Game from file game.h
*      param: int position, the position of the space
*      @alexConache & CiroAlonso                       
*/


Id game_get_space_id_at(Game* game, int position) {

  if (position < 0 || position >= MAX_SPACES) {
    return NO_ID;
  }

  return space_get_id(game->spaces[position]);
}



/**
*      @brief Updates the game 
*                              
*      Updates the game using the callback functions                        
*                                      
*      param: structure Game from file game.h
*      param: Enum_command cmd to choose which callback function you want  
*      @alexConache & CiroAlonso                       
*/


STATUS game_update(Game* game, Command *pc) {
  Enum_command last_cmd;
  last_cmd = command_get_command(pc);
  
  /*  Sets the structure command of game equal as the one chosen by the player */
  if (command_setCommand(game->cmd, last_cmd) == NULL) return ERROR;
  if (command_setName(game->cmd, command_getName(pc)) == NULL) return ERROR;
  

  (*game_callback_fn_list[last_cmd])(game);
  
  return OK;
}



/**
*      @brief Returns the last command
*                                                              
*      param: structure Game from file game.h  
*      @AlexConache & CiroAlonso                       
*/


Enum_command game_get_last_command(Game* game){

  return command_get_command(game->cmd);
}
  
  



/**
*      @brief Print out the game
*                              
*      Print out the player location as well as the object location                         
*                                      
*      param: structure Game from file game.h  
*      @AlexConache & CiroAlonso                       
*/

void game_print_data(Game* game) {
  int i = 0;

  printf("\n\n-------------\n\n");

  printf("=> Spaces: \n");
  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++) {
    space_print(game->spaces[i]);
  }
  /*
  for(i=0; i<MAX_OBJECTS && game->objects[i] != NULL; i++){
    printf("=> %d. Object location: %d\n", i+1, (int) game_get_object_location(game,game->objects[i]));
  }
  */
  printf("=> Player location: %d\n", (int) game_get_player_location(game));
  printf("prompt:> ");
}




/**
*      @brief The game is finished 
*                              
*      param: structure Game from file game.h 
*      @AlexConache & CiroAlonso                       
*/

BOOL game_is_over(Game* game) {
  return FALSE;
}

void game_callback_roll(Game* game){


  
  die_roll(game->dice);
  game->last_roll = die_get_lastRoll(game->dice);

  
  return;
}


/**
*      @brief Pick up the object from the player location
*                              
*      Checks for multiple errors, if not gets the object from the space the 
*       the player is and if found, gives it to the player   
*
*      param: structure Game from file game.h 
*      @AlexConache & CiroAlonso                       
*/


void game_callback_pickup(Game *game){
  Id object_id = NO_ID; /* El id del objeto del nombre pasado*/ 
	int i = 0;
  char pName[MAX_NAME+1] = " ";

  strcpy(pName, command_getName(game->cmd));

  if(!game || pName == NULL){
    return;
  }
  

  for(i=0; i< MAX_OBJECTS && i< inventory_get_maxObjects(player_get_inventory(game->players)) && game->objects[i] != NULL; i++){
	  /*  Si existe un objeto con ese nombre comprueba que este en el espacio del jugador  */
    if((strcasecmp(object_get_name(game->objects[i]), pName) == 0)) {
      object_id = object_get_id(game->objects[i]);

      /*  Si esta el objeto en el espacio del jugador lo elimina del espacio y se lo da al jugador */ 
      game_space_get_object(game, object_id);
      player_set_inventory(game->players, object_id);
      
  
    }

  }
  return;
}


/**
*     @brief Drop in the object from the player location
*                              
*      Checks for multiple errors, if not set the object from player to false                        
*      to say that now he hasn't the object in his possesion and place the object 
*                          in the laction of the player
*
*      @param: structure Game from file game.h 
*      @authors Alexandra Conache & Ciro Alonso                       
*/



void game_callback_drop(Game *game){
  Id object_id = NO_ID;
  int i;
  char *pName;

  pName = command_getName(game->cmd);

  if(!game || pName == NULL){
    return;
  }

  for(i=0; i < MAX_OBJECTS && game->objects[i] != NULL; i++){
    if(strcasecmp (object_get_name(game->objects[i]), pName) == 0){
      object_id = object_get_id(game->objects[i]);
      if(player_drop_object(game->players,object_id) == ERROR) return;
      if(game_space_set_object(game, object_id) == ERROR) return;
      
    }
  }

}

void game_callback_move(Game* game){
  Id space_id = NO_ID;

  char* pName;

  pName = command_getName(game->cmd);
  if(!game || pName == NULL) return;

  space_id = game_get_player_location(game);
  if(space_id == NO_ID) return;

  if(strlen(pName) == 1){
    if(strcasecmp(&pName[0],"n")==0){
     game_callback_back(game);
     return;
    }
    else if(strcasecmp(&pName[0],"s")==0){
      game_callback_next(game);
      return;
    }
    else if(strcasecmp(&pName[0],"e")==0){
      game_callback_right(game);
      return;
    }
    else if(strcasecmp(&pName[0],"w")==0){
      game_callback_left(game);
      return;
    }
  }
  else if(strlen(pName) > 1){
    if(strcasecmp(pName,"north")==0){
      game_callback_back(game);
      return;
    }
    else if(strcasecmp(pName,"south")==0){
      game_callback_next(game);
      return;
    }
    else if(strcasecmp(pName,"east")==0){
      game_callback_right(game);
      return;
    }
    else if(strcasecmp(pName,"west")==0){
      game_callback_left(game);
      return;
    }
  }
}


void game_callback_unknown(Game* game) {
}

void game_callback_exit(Game* game) {
}


/**
*      @brief It moves the player location one further box 
*                              
*      It moves the player one box futher from his actual position
*
*      param: structure Game from file game.h 
*      @AlexConache & CiroAlonso                       
*/


void game_callback_next(Game* game) {
  int i = 0, j=0;
  Id current_id = NO_ID;
  Id space_id = NO_ID;
  Id link_id = NO_ID;
  Id south_id = NO_ID;

  space_id = game_get_player_location(game);
  if (space_id == NO_ID) {
    return;
  }

  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++) {
    current_id = space_get_id(game->spaces[i]);
    if (current_id == space_id) {
      link_id = space_get_south_link(game->spaces[i]);
      for(j = 0; j<MAX_LINK;j++){
        if(link_get_id(game->links[j]) == link_id){
          if(link_get_link1(game->links[j]) == current_id){
            south_id = link_get_link2(game->links[j]);
            break;
          }else{
            south_id = link_get_link1(game->links[j]);
            break;
          }
        }else{
          south_id = NO_ID;
        }
      }
      if(south_id != NO_ID){
        game_set_player_location(game, south_id);
      }else{
        return;
      }
    }
  }
  return;
}

/**
*      @brief It moves the player one box back
*
*      It moves the player one box back from his actual position
*                              
*      param: structure Game from file game.h 
*      @AlexConache & CiroAlonso                       
*/


void game_callback_back(Game* game) {
  int i = 0, j=0;
  Id current_id = NO_ID;
  Id space_id = NO_ID;
  Id link_id = NO_ID;
  Id north_id = NO_ID;

  space_id = game_get_player_location(game);
  if (space_id == NO_ID) {
    return;
  }

  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++) {
    current_id = space_get_id(game->spaces[i]);
    if (current_id == space_id) {
      link_id = space_get_north_link(game->spaces[i]);
      for(j = 0; j<MAX_LINK;j++){
        if(link_get_id(game->links[j]) == link_id){
          if(link_get_link1(game->links[j]) == current_id){
            north_id = link_get_link2(game->links[j]);
            break;
          }else{
            north_id = link_get_link1(game->links[j]);
            break;
          }
        }else{
          north_id = NO_ID;
        }
      }
      if(north_id != NO_ID){
        game_set_player_location(game, north_id);
      }else{
        return;
      }
    }
  }
  return;
}


/**
*      @brief It moves the player to the box linked on the left
*
*      It moves the player to the left box from his actual position
*
*      param: structure Game from file game.h
*      @AlexConache & CiroAlonso
*/
void game_callback_left(Game* game) {

  int i = 0, j=0;
  Id current_id = NO_ID;
  Id space_id = NO_ID;
  Id link_id = NO_ID;
  Id west_id = NO_ID;

  space_id = game_get_player_location(game);
  if (space_id == NO_ID) {
    return;
  }

  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++) {
    current_id = space_get_id(game->spaces[i]);
    if (current_id == space_id) {
      link_id = space_get_west_link(game->spaces[i]);
      for(j = 0; j<MAX_LINK;j++){
        if(link_get_id(game->links[j]) == link_id){
          if(link_get_link1(game->links[j]) == current_id){
            west_id = link_get_link2(game->links[j]);
            break;
          }else{
            west_id = link_get_link1(game->links[j]);
            break;
          }
        }else{
          west_id = NO_ID;
        }
      }
      if(west_id != NO_ID){
        game_set_player_location(game, west_id);
      }else{
        return;
      }
    }
  }
  return;
}

/**
*      @brief It moves the player to the box linked on the right
*
*      It moves the player to the right box from his actual position
*
*      param: structure Game from file game.h
*      @AlexConache & CiroAlonso
*/
void game_callback_right(Game* game) {

  int i = 0, j=0;
  Id current_id = NO_ID;
  Id space_id = NO_ID;
  Id link_id = NO_ID;
  Id east_id = NO_ID;

  space_id = game_get_player_location(game);
  if (space_id == NO_ID) {
    return;
  }

  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++) {
    current_id = space_get_id(game->spaces[i]);
    if (current_id == space_id) {
      link_id = space_get_east_link(game->spaces[i]);
      for(j = 0; j<MAX_LINK;j++){
        if(link_get_id(game->links[j]) == link_id){
          if(link_get_link1(game->links[j]) == current_id){
            east_id = link_get_link2(game->links[j]);
            break;
          }else{
            east_id = link_get_link1(game->links[j]);
            break;
          }
        }else{
          east_id = NO_ID;
        }
      }
      if(east_id != NO_ID){
        game_set_player_location(game, east_id);
      }else{
        return;
      }
    }
  }
  return;
}







/**
*      @brief Get the space he is reading 
*                                    
*      param: structure Game from file game.h 
*      param: char filename, necessary to load spaces 
*      @date  17/02/2019 
*      @authors Alexandra Conache & CiroAlonso                       
*/

Space* game_get_space(Game* game, Id id){
  int i = 0;

  if (id == NO_ID) {
    return NULL;
  }
    
  for (i = 0; i < MAX_SPACES && game->spaces[i] != NULL; i++) {
    if (id == space_get_id(game->spaces[i])){
      return game->spaces[i];
    }
  }
    
  return NULL;
}

STATUS game_set_player_location(Game* game, Id id){
  if(!game || id == NO_ID){
    return ERROR;
  }
  player_set_location(game->players,id);

  return OK;
}


Id game_get_player_location(Game* game){
  return player_get_location(game->players);
}

Id game_get_object_location(Game* game, Object *object){
  int j = 0;
  Id obj_id = NO_ID;
  if(!game)return NO_ID;

  
  for(j=0; j<MAX_SPACES ; j++){
    obj_id = object_get_id(object);
    if((space_object_is_in(game->spaces[j], obj_id)) == TRUE){
      return space_get_id(game->spaces[j]);
      
    } 
  }
  return NO_ID;
}


/*    Set an object to the space of the player   */
STATUS game_space_set_object(Game *game, Id id){
  Id player_loc = NO_ID;
  int i;
  if(!game || id <= 0){
    return ERROR;
  }
  player_loc = game_get_player_location(game);

  for(i=0; i<MAX_SPACES && game->spaces[i] != NULL; i++){
    if(space_get_id(game->spaces[i])==player_loc){

      if(space_set_object(game->spaces[i], id)== ERROR){
        return ERROR;
      }
      
      return OK;
    }
  }

  return ERROR;

}


/*  Returns TRUE if deleted properly the object from the space the player is in  */
STATUS game_space_get_object(Game *game, Id id){
  Id player_loc = NO_ID;
  int i;
  if(!game || id <= 0){
    return ERROR;
  }
  player_loc = game_get_player_location(game);

  for(i=0; i<MAX_SPACES && game->spaces[i] != NULL; i++){
    if(space_get_id(game->spaces[i]) == player_loc){
      /* This function (space_get_object) returns OK if deleted properly the object */
      if(space_get_object(game->spaces[i], id)==OK){
        return OK;
      }
      else{
        return ERROR;
      }
      
      return ERROR;
    }
  }
  return ERROR;
}

/* !< Sets the object to the space you want */
STATUS game_set_object_space(Game *game, Id spaceID, Id objectId){
  int i;

  for(i=0; i<MAX_SPACES && game->spaces[i] != NULL; i++){
      if(space_get_id(game->spaces[i]) == spaceID){
      space_set_object(game->spaces[i], objectId);
      return OK;
    }
  }

  return ERROR;
}

/*  Gets the object to the space you want */
BOOL game_get_object_space(Game *game, Id spaceID, Id objectId){
  int i;
  if(objectId == NO_ID){
    return FALSE;
  }
  for(i=0; i<MAX_SPACES && game->spaces[i] != NULL; i++){
    if(space_get_id(game->spaces[i]) == spaceID){     
      if(space_object_is_in(game->spaces[i], objectId)){
        return TRUE;
      }
    }
  }

  return FALSE;
}

STATUS game_add_object(Game* game, Object* object) {
  int i = 0;

  if (object == NULL) {
    return ERROR;
  }

  while ( (i < MAX_OBJECTS) && (game->objects[i] != NULL)){
    i++;
  }

  if (i >= MAX_OBJECTS) {
    return ERROR;
  }

  game->objects[i] = object;

  return OK;
}

Player* game_get_player(Game *game){
  if(!game) return NULL;

  return game->players;
}

Die* game_get_die(Game *game){
  if(!game)return NULL;
  return game->dice;
}

Object* game_get_object(Game* game, Id id){
  int i = 0;

  if (id == NO_ID) {
    return NULL;
  }
    
  for (i = 0; i < MAX_OBJECTS && game->objects[i] != NULL; i++) {
    if (id != NO_ID && id == object_get_id(game->objects[i])){
      return game->objects[i];
    }
  }
    
  return NULL;
}

STATUS game_add_link(Game* game, Link* link) {
  int i = 0;

  if (game == NULL || link == NULL) {
    return ERROR;
  }

  while ( (i < (4 * MAX_SPACES)) && (game->links[i] != NULL)){
    i++;
  }

  if (i >= (4 * MAX_SPACES) ){
    return ERROR;
  }

  game->links[i] = link;

  return OK;
}

Id game_get_link_id_at(Game* game, int position) {

  if (position < 0 || position >= MAX_SPACES) {
    return NO_ID;
  }

  return link_get_id(game->links[position]);
}

Link* game_get_link(Game* game, Id id){
  int i = 0;

  if (id == NO_ID) {
    return NULL;
  }
    
  for (i = 0; i < MAX_SPACES && game->links[i] != NULL; i++) {
    if (id == link_get_id(game->links[i])){
      return game->links[i];
    }
  }
    
  return NULL;
}

Object* game_get_player_object(Game* game, Player* player){
  Inventory* inventory = NULL;
  Id object_id = NO_ID;
  int i=0;

  if(!game||!player) return NULL;
  inventory = player_get_inventory(player);
  if( inventory != NULL){
    for(i=0;i<MAX_OBJECTS;i++){
    object_id = set_get_id(inventory_get_set(inventory),i);
    if(inventory_ask_id(inventory,object_id) == TRUE){
    return game_get_object(game, object_id);
      }
    }
  }
  return NULL;
}

void game_callback_inspect(Game* game){
  int i= 0;
  Object* object = NULL;
  Id player_location = NO_ID;
  char* pName = "";

  if(!game)return;

  player_location = game_get_player_location(game);
  if(player_location == NO_ID)return;

  pName = command_getName(game->cmd);
  if(pName == NULL)return;

  if(strlen(pName) == 1){
    if(strcasecmp(&pName[0],"s") ==0){
      for(i=0; i<MAX_SPACES && game->spaces[i]; i++){
        if(player_location == space_get_id(game->spaces[i])){
          strcpy(game->description,space_get_description(game->spaces[i]));
          return;
        }
      }
      return;
    }else{
      for(i=0;i<MAX_OBJECTS;i++){
        if(game_get_object_location(game,game->objects[i]) == player_location || player_has_object(game->players,object_get_id(game->objects[i]))==OK){
          if(object_get_name(game->objects[i]) == pName){
            object = game->objects[i];
          }
        }
      }
      if (!object) return;

      strcpy(game->description,object_get_description(object));
      return;
    }
  }
  else if(strlen(pName) > 1){
    if(strcasecmp(pName,"space")==0){
      for(i=0; i<MAX_SPACES && game->spaces[i]; i++){
        if(player_location == space_get_id(game->spaces[i])){
          strcpy(game->description,space_get_description(game->spaces[i]));
          return;
        }
      }
      return;
    }else{
      for(i=0;i<MAX_OBJECTS;i++){
        if(game_get_object_location(game,game->objects[i]) == player_location || player_has_object(game->players,object_get_id(game->objects[i]))==OK){
          if(strcasecmp(object_get_name(game->objects[i]),pName)==0){
            object = game->objects[i];
          }
        }
      }
      if (!object) return;

      strcpy(game->description,object_get_description(object));
      return;
    }
  }  
}

char* game_get_description(Game* game){
  if(!game) return ERROR;
  return game->description;
}