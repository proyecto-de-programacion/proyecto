#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "inventory.h"


struct _Inventory {
  Set *set;  
  int maxObjects;
};

Inventory* inventory_create(){
    Inventory *newInventory = NULL;

    
    newInventory = (Inventory*) malloc (sizeof(Inventory));

    if (newInventory == NULL) {
      return NULL;
    }
    
    newInventory->maxObjects = 0;
    newInventory->set = set_create();

    return newInventory;
}

STATUS inventory_destroy(Inventory* inventory){
    if (!inventory) {
      return ERROR;
    }
    set_destroy(inventory->set);
    free(inventory);

    return OK;
}

Set * inventory_get_set(Inventory* inventory){
  if (!inventory ) {
    return ERROR;
  }
  
  return inventory->set;
}

int inventory_get_maxObjects(Inventory* inventory){
  if (!inventory) {
    return ERROR;
  }
  return inventory->maxObjects;
    
}


STATUS inventory_set_set(Inventory* inventory, Id id){
  if (!inventory || id == NO_ID) {
    return ERROR;
  }

  return set_add(inventory->set,id);
}


STATUS inventory_set_maxObjects(Inventory* inventory, int new_size){
  if (!inventory || new_size < 0) {
    return ERROR;
  }
  inventory->maxObjects = new_size;
  return OK;
}

STATUS inventory_print(Inventory* inventory){
  
  if (!inventory) {
    return ERROR; /* INVENTORY_H */
  }

  fprintf(stdout, "--> Inventory \n");
  
  fprintf(stdout, "--> Max objects: %d \n", inventory->maxObjects);
  
  set_print(inventory->set);

  
  
  return OK;
}

STATUS inventory_delete_object(Inventory *inventory , Id object_id){
  if (!inventory || object_id == NO_ID){
    return ERROR;
  }
  if (set_delete_id(inventory->set,object_id)==ERROR){
    return ERROR;
  }

  return OK;
}

STATUS inventory_add_object(Inventory *inventory ,Id object_id){
  if (!inventory || object_id == NO_ID){
    return ERROR;
  }
  if (set_add(inventory->set,object_id)==ERROR){
    return ERROR;
  }

  return OK;
}

BOOL inventory_ask_id(Inventory* inventory, Id object_id){
  int i=0;
  if(!inventory || object_id == NO_ID) return FALSE;

  for(i=0; i< inventory->maxObjects;i++){
    if(set_get_id(inventory->set,i) == object_id){
      return TRUE;
    }
  }
  return FALSE;
}