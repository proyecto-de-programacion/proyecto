#ifndef INVENTORY_H
#define INVENTORY_H

#include "types.h"
#include "set.h"

typedef struct _Inventory Inventory;


Inventory* inventory_create();
STATUS inventory_destroy(Inventory* inventory);

Set * inventory_get_set(Inventory* inventory);
int inventory_get_maxObjects(Inventory* inventory);

STATUS inventory_set_set(Inventory* inventory, Id id);
STATUS inventory_set_maxObjects(Inventory* inventory, int new_size);

STATUS inventory_print(Inventory* inventory);
STATUS inventory_delete_object(Inventory *inventory , Id object_id);
STATUS inventory_add_object(Inventory *inventory ,Id object_id);
BOOL inventory_ask_id(Inventory* inventory, Id object_id);
#endif
