#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "die.h"
#include "types.h"


struct _Die {
    Id id;
    int last_roll;
};



/* Creates the die and initializes the components and returns the die*/
Die* die_create(){
    
  Die *newDie = NULL;
  
  newDie = (Die *) malloc(sizeof (Die));

  if (newDie == NULL) {
    return NULL;
  }
  newDie->id =NO_ID;
  newDie->last_roll = 0;

  return newDie; 
}



 /* Desrtoys the dynamic memory made for the die structure */
STATUS die_destroy(Die* die){
    
    if (!die) {
        return ERROR;
    }

    free(die);
    return OK;
}



/* Creates a random number from 1 to 6 and returns it */
int die_roll(Die *die){
  time_t time_randomizer;
  int random;

  if (!die){
    return -1;
  }

  srand(time(NULL));

  srand((unsigned) time(&time_randomizer));
  random = ((rand()%6)+1);
  
  if(random == 0){
    return -1;
  }

  return random;
}





/* Prints out the die structure and his elements */
STATUS die_print(Die* die){
  if(!die){
    return ERROR;
  }
  fprintf(stdout,"-->Die ID: %ld | Last Roll: %d\n", die_get_id(die), die_get_lastRoll(die));

  return OK;
}



/* Returns the last roll made */
int die_get_lastRoll(Die *d){
  if(!d){
    return -1;
  }
  return d->last_roll;
}

/* Returns the id */
Id die_get_id(Die* die){
  if(!die){
    return NO_ID;
  }
  return die->id;
}