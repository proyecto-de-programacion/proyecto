/**
 * @brief It defines a screen
 *
 * @file screen.h
 * @author Profesores PPROG
 * @version 1.0
 * @date 11-01-2017
 * @copyright GNU Public License
 */

#ifndef __SCREEN__
#define __SCREEN__

/**
 * Definition of constant values
 */
#define SCREEN_MAX_STR 80

/**
 * Definition of data structure
 */
typedef struct _Area Area;

/**
 *  Delcaration of public functions
 */



/**
 *  @brief Creates the screen
 *
 *  screen_init   Reserves enough memory to create the screen and makes sure that
 *                everything is working properly
 *
 *  @date 17/02/2019
 *  @authors Alonso Aquino Ciro, Conache Alexandra
 *
 */
void  screen_init();

/**
 *  @brief Destroys the screen by freeing the allocated memory
 *
 *  screen_destroy Frees the memory we reserved with the function screen_create
 *                 it also assigns it a NULL value to tie up loose ends
 *                 furthermore it has a control code to prevent possible
 *                 errors
 *
 *  @date 17/02/2019
 *  @authors Alonso Aquino Ciro, Conache Alexandra
 *
 *  @param screen the screen created that's going to be destroyed
 *
 */
void  screen_destroy();


void  screen_paint();
void  screen_gets(char *str);


/**
 *  @brief Creates the area on the screen
 *
 *  screen_area_init   Reserves enough memory to create the area and makes sure that
 *                everything is working properly
 *
 *  @date 17/02/2019
 *  @authors Alonso Aquino Ciro, Conache Alexandra
 *
 */

Area* screen_area_init(int x, int y, int width, int height);


/**
 *  @brief Destroys the area by freeing the allocated memory
 *
 *  screen_area_destroy Frees the memory we reserved with the function screen_area_init
 *                      it also assigns it a NULL value to tie up loose ends
 *                      furthermore it has a control code to prevent possible
 *                      errors
 *
 *  @date 17/02/2019
 *  @authors Alonso Aquino Ciro, Conache Alexandra
 *
 *  @param area the area created that's going to be destroyed
 *
 */
void  screen_area_destroy(Area* area);
void  screen_area_clear(Area* area);
void  screen_area_reset_cursor(Area* area);
void  screen_area_puts(Area* area, char *str);

#endif
