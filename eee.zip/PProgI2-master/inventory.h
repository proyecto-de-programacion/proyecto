/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   inventory.h
 * Author: Sara
 *
 * Created on 31 de marzo de 2019, 11:00
 */

#ifndef INVENTORY_H
#define INVENTORY_H

#include "types.h"
#include "set.h"

typedef struct _Inventory Inventory;

/**
 *  @brief Creates the inventory
 *
 *  inventory_create Reserves enough memory to create the inventory
 *                   it assigns it an id, a name and a location
 *                   as well as making sure everything is working
 *                   properly
 *
 *  @date 01/03/2019
 *  @authors Sara Erika Catana
 *
 *
 *
 */
Inventory* inventory_create(int maxObjects);

/**
 *  @brief Destroys the inventory by freeing the allocated memory
 *
 *  inventory_destroy Frees the memory we reserved with the function inventory_create
 *                    it also assigns it a NULL value to tie up loose ends
 *                    furthermore it has a control code to prevent possible
 *                    errors
 *
 *  @date 01/03/2019
 *  @authors Sara Erika Catana
 *
 *  @param inventory the inventory created that's going to be destroyed
 *
 */
STATUS inventory_destroy(Inventory* inventory);


/**
 *  @brief Returns the inventorie's object's identifiers
 *
 *  inventory_get_objectsIdentifiers   Is a function that assesses whether the inventory exists and
 *                                     it calls the inventorie's structure to get its identify
 *
 *  @date 01/03/2019
 *  @authors Sara Erika Catana
 *
 *  @param inventory is the inventory we created
 *  @param inventory is the player's inventory
 */
Set * inventory_get_objectsIdentifiers(Inventory* inventory, Id id);

/**
 *  @brief Returns the inventorie's max object's 
 *
 *  inventory_get_maxObjects           Is a function that assesses whether the inventory exists and
 *                                     it calls the inventorie's structure to get its max objects
 *
 *  @date 01/03/2019
 *  @authors Sara Erika Catana
 *
 *  @param inventory is the inventory we created
 *  @param inventory is the player's inventory
 */
int inventory_get_maxObjects(Inventory* inventory);


/**
 *  @brief 
 *
 *  inventory_set_objetsIdentifiers
 *
 *
 *  @date 02/03/2019
 *  @authors Sara Erika Catana
 *
 *  @param inventory is the inventory we created
 *  @param 
 */
STATUS inventory_set_objetsIdentifiers(Inventory* inventory, Id id);

/**
 *  @brief 
 *
 *  inventory_set_maxObjects 
 *
 *
 *  @date 02/03/2019
 *  @authors Sara Erika Catana
 *
 *  @param inventory is the inventory we created
 *  @param 
 */
STATUS inventory_set_maxObjects(Inventory* inventory, int maxObjects);

STATUS inventory_print(Inventory* inventory);

#endif /* INVENTORY_H */

