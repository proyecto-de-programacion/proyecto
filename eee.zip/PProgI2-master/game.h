/** 
 * @brief It defines the game interface
 * for each command
 * 
 * @file game.h
 * @AlexConache y CiroAlonso
 * @version 2.0 
 * @date 17/02/2019
 */

#ifndef GAME_H
#define GAME_H

#include "command.h"
#include "space.h"
#include "player.h"
#include "types.h"
#include "die.h"
#include "object.h"
#include "link.h"


typedef struct _Game Game;



/**
*      @brief Creates the game
*                              
*      It creates the game, load the spaces to NULL, creates the player
*           and the array of objects and initializes and initializes their Id 
*                     to the local variable i last_cmd to no command                     
*                                      
*      param: structure Game from file game.h
*
*      @alexConache & CiroAlonso                       
*/
STATUS game_create(Game* game);

/**
*      @brief Creates the game from file
*                              
*      It creates the game, load the spaces and set the                                 
*             locations of the player and the object                         
*                                      
*      param: structure Game from file game.h
*      param: char filename, necessary to load spaces  
*      @alexConache & CiroAlonso                       
*/
STATUS game_create_from_file(Game* game, char* filename);

/**
*     @brief Destroys de memory peviously called   

*     Destroys the memroy created for each space, the player                                
*                         and the object             
*     param: structure Game from file game.h                                
*     @alexConache & CiroAlonso                                 
*/
STATUS game_destroy(Game* game);

/**
*      @brief Adds space to the game
*                                   
*      param: structure Game from file game.h
*      param: struct Space from file space.c  
*      @alexConache & CiroAlonso                       
*/
STATUS game_add_space(Game* game, Space* space);

STATUS game_add_link(Game* game, Link* link);

/**
*      @brief Returns the id of the space
*                              
*      Checks for errors, if not returns the id of the space of the game
*                 thanks to the finction space_get_id
*      param: structure Game from file game.h
*      param: int position, the position of the space
*      @alexConache & CiroAlonso                       
*/
Id game_get_space_id_at(Game* game, int position);

/**
*      @brief Updates the game 
*                              
*      Updates the game using the callback functions                        
*                                      
*      param: structure Game from file game.h
*      param: Enum_command cmd to choose which callback function you want  
*      @alexConache & CiroAlonso                       
*/
STATUS game_update(Game* game, Command *cmd);

/**
*      @brief Returns the last command
*                                                              
*      param: structure Game from file game.h  
*      @AlexConache & CiroAlonso                       
*/
Enum_command game_get_last_command(Game* game);

/**
*      @brief Print out the game
*                              
*      Print out the player location as well as the object location                         
*                                      
*      param: structure Game from file game.h  
*      @AlexConache & CiroAlonso                       
*/
void game_print_data(Game* game);

/**
*      @brief The game is finished 
*                              
*      param: structure Game from file game.h 
*      @AlexConache & CiroAlonso                       
*/
BOOL   game_is_over(Game* game);

/**
*      @brief Get the space he is reading 
*                                    
*      param: structure Game from file game.h 
*      param: char filename, necessary to load spaces 
*      @date  17/02/2019 
*      @authors Alexandra Conache & CiroAlonso                       
*/
Space* game_get_space(Game* game, Id id);


/**
*      @brief Set the player location he is reading 
*                                    
*      param: structure Game from file game.h 
*      param:  
*      @date  17/02/2019 
*      @authors Alexandra Conache & CiroAlonso                       
*/

STATUS game_set_player_location(Game* game, Id id);

/**
*      @brief Get the player location he is reading 
*                                    
*      param: structure Game from file game.h 
*      param: 
*      @date  17/02/2019 
*      @authors Alexandra Conache & CiroAlonso                       
*/
Id game_get_player_location(Game* game);

/**
*      @brief Set the object he is reading 
*                                    
*      param: structure Game from file game.h 
*      param:  
*      @date  17/02/2019 
*      @authors Alexandra Conache & CiroAlonso                       
*/
STATUS game_space_setObject(Game *game, Id id);


/**
*      @brief Get the object he is reading 
*                                    
*      param: structure Game from file game.h 
*      param:  
*      @date  17/02/2019 
*      @authors Alexandra Conache & CiroAlonso                       
*/
STATUS game_space_getObject(Game *game, Id id);

/**
*      @brief Get the link he is reading 
*                                    
*      param: structure Game from file game.h 
*      param:  
*      @date  17/02/2019 
*      @authors Alexandra Conache & CiroAlonso                       
*/
Id game_get_link_id_at(Game* game, int position);

/**
*      @brief 
*                                    
*      param: structure Game from file game.h 
*      param: 
*      @date  17/02/2019 
*      @authors Alexandra Conache & CiroAlonso                       
*/
STATUS game_setObject_space(Game *game, Id spaceID, Id objectId);

/**
*      @brief 
*                                    
*      param: structure Game from file game.h 
*      param: 
*      @date  17/02/2019 
*      @authors Alexandra Conache & CiroAlonso                       
*/
BOOL game_getObject_space(Game *game, Id spaceID, Id objectId);

/* !<  Doesn't appear in the code for the current moment  */
void   game_print_screen(Game* game);

















#endif
