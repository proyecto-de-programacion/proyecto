/** 
* @brief It defines a textual game reader
* 
* @file game_reader.h
* @author Alexandra Conache
* @version 2.0 
* @date 25/02/2019
*/


#ifndef GAME_READER_H
#define GAME_READER_H

#include "command.h"
#include "game.h"



/**
*      @brief Reads and loads the spaces 
*                              
*      In charge of reading the positions of the boxes and how the are interconnected                        
*      and load the spaces required from the file
*       
*
*      param: structure Game from file game.h 
*      param: char filename, necessary to load spaces 
*      @date  8/03/2019 
*      @author Alexandra Conache                    
*/ 
STATUS game_reader_load_spaces(Game* game, char* filename);

/**
*      @brief Reads and loads the objects 
*                              
*      In charge of reading the positions of the boxes and how the are interconnected                        
*      and load the objects required from the file
*       
*
*      @param: structure Game from file game.h 
*      @param: char filename, necessary to load objects 
*      @date  8/03/2019 
*      @author Alexandra Conache                    
*/
STATUS game_reader_load_objects(Game* game, char* filename);


/**
*      @brief Reads and loads the links 
*                              
*      In charge of reading the positions of the boxes and how the are interconnected                        
*      and load the links required from the file
*       
*
*      @param: structure Game from file game.h 
*      @param: char filename, necessary to load links 
*      @date  01/04/2019 
*      @authors Alexandra Conache & Sara Erika Catana                  
*/
STATUS game_reader_load_links(Game* game, char* filename);
#endif