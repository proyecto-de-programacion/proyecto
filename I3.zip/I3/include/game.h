/** 
 * @brief It defines the game interface
 * for each command
 * 
 * @file game.c
 * @author Alexandra Conache y CiroAlonso
 * @version 2.0 
 * @date 17/02/2019
 */

#ifndef GAME_H
#define GAME_H

#include "command.h"
#include "space.h"
#include "player.h"
#include "types.h"
#include "die.h"
#include "object.h"

#include "link.h"

typedef struct _Game Game;

/**
*      @brief Adds space to the game
*                                   
*      param: structure Game from file game.c
*      param: struct Space from file space.c  
*      @author Alexandra Conache & CiroAlonso                       
*/
STATUS game_add_space(Game* game, Space* space);
/**
*      @brief Adds links to the game
*                                   
*      param: structure Game from file game.c
*      param: struct Link from file space.c  
*      @author Alexandra Conache & CiroAlonso                       
*/
STATUS game_add_link(Game* game, Link* link);

/**
*      @brief Creates the game
*                              
*      It creates the game, load the spaces to NULL, creates the player
*           and the array of objects and initializes and initializes their Id 
*                     to the local variable i last_cmd to no command                     
*                                      
*      @param: structure Game from file game.c
*
*      @author Alexandra Conache & CiroAlonso                       
*/
STATUS game_create(Game** game);

/**
*      @brief Creates the game from file
*                              
*      It creates the game, load the spaces and set the                                 
*             locations of the player and the object                         
*                                      
*      param: structure Game from file game.c
*      param: char filename, necessary to load spaces  
*      @author Alexandra Conache & CiroAlonso                       
*/
STATUS game_create_from_file(Game** game, char* filename);

/**
*      @brief Updates the game 
*                              
*      Updates the game using the callback functions                        
*                                      
*      param: structure Game from file game.c
*      param: Enum_command cmd to choose which callback function you want  
*      @author Alexandra Conache & CiroAlonso                       
*/
STATUS game_update(Game* game, Command *cmd);

/**
*     @brief Destroys de memory peviously called   

*     Destroys the memroy created for each space, the player                                
*                         and the object             
*     param: structure Game from file game.c                                
*     @author Alexandra Conache & CiroAlonso                                 
*/
STATUS game_destroy(Game* game);

/**
*      @brief The game is finished 
*                              
*      param: structure Game from file game.c 
*      @author Alexandra Conache & CiroAlonso                       
*/
BOOL   game_is_over(Game* game);

/* !<  Doesn't appear in the code for the current moment  */
void   game_print_screen(Game* game);

/**
*      @brief Print out the game
*                              
*      Print out the player location as well as the object location                         
*                                      
*      param: structure Game from file game.c  
*      @author Alexandra Conache & CiroAlonso                       
*/
void game_print_data(Game* game);

/**
*      @brief Get the space he is reading 
*                                    
*      param: structure Game from file game.c 
*      param: char filename, necessary to load spaces 
*      @date  17/02/2019 
*      @author Alexandra Conache & CiroAlonso                       
*/
Space* game_get_space(Game* game, Id id);

/**
*      @brief Returns the last command
*                                                              
*      param: structure Game from file game.c  
*      @author Alexandra Conache & CiroAlonso                       
*/
Enum_command game_get_last_command(Game* game);

/**
*      @brief Returns the id of the space
*                              
*      Checks for errors, if not returns the id of the space of the game
*                 thanks to the finction space_get_id
*      param: structure Game from file game.c
*      param: int position, the position of the space
*      @author Alexandra Conache & CiroAlonso                       
*/
Id game_get_space_id_at(Game* game, int position);
/**
*      @brief Set the player location he is reading 
*                                    
*      param: structure Game from file game.c 
*      param:  
*      @date  17/02/2019 
*      @author Alexandra Conache & CiroAlonso                       
*/
STATUS game_set_player_location(Game* game, Id id);
/**
*      @brief Get the player location he is reading 
*                                    
*      @param: structure Game from file game.c 
*      
*      @date  17/02/2019 
*      @author Alexandra Conache & CiroAlonso                       
*/
Id game_get_player_location(Game* game);
/**
*      @brief Get the object location he is reading 
*                                    
*      @param: structure Game from file game.c 
*      
*      @date  17/02/2019 
*      @author Alexandra Conache & CiroAlonso                       
*/
Id game_get_object_location(Game* game,Object* object);

/**
*      @brief Set the object he is reading 
*                                    
*      @param: structure Game from file game.c 
*       
*      @date  17/02/2019 
*      @author Alexandra Conache & CiroAlonso                       
*/
STATUS game_space_set_object(Game *game, Id id);

/**
*      @brief Get the object he is reading 
*                                    
*      @param: structure Game from file game.c 
*      
*      @date  17/02/2019 
*      @author Alexandra Conache & CiroAlonso                       
*/
STATUS game_space_take_object(Game *game, Id id);

/**
*      @brief Sets an object in a specific space
*                                    
*      @param: structure Game from file game.c 
*       
*      @date  17/02/2019 
*      @author Alexandra Conache & CiroAlonso                       
*/
STATUS game_set_object_space(Game *game, Id spaceID, Id objectId);
/**
*      @brief Returns the object found in the space inquired
*                                    
*      param: structure Game from file game.c 
*      param: 
*      @date  17/02/2019 
*      @author Alexandra Conache & CiroAlonso                       
*/
BOOL game_get_object_space(Game *game, Id spaceID, Id objectId);
/**
*      @brief Adds objects to the game
*                                   
*      param: structure Game from file game.c
*      param: struct Object from file space.c  
*      @author Alexandra Conache & CiroAlonso                       
*/
STATUS game_add_object(Game* game, Object* object);
/**
*      @brief Returns the field player from Game's structure
*                                   
*      param: structure Game from file game.c
*
*      @author Alexandra Conache                      
*/
Player* game_get_player(Game *game);
/**
*      @brief Returns the field die from Game's structure
*                                   
*      param: structure Game from file game.c
*
*      @author Alexandra Conache                      
*/
Die* game_get_die(Game *game);
/**
*      @brief Returns the field object from Game's structure
*                                   
*      param: structure Game from file game.c
*
*      @author Alexandra Conache                      
*/
Object* game_get_object(Game* game, Id id);
/**
*      @brief Get the link he is reading 
*                                    
*      @param: structure Game from file game.c 
*        
*      @date  17/02/2019 
*      @author Alexandra Conache & CiroAlonso                       
*/
Id game_get_link_id_at(Game* game, int position);
/**
*      @brief Returns the field link from Game's structure
*                                   
*      @param: structure Game from file game.c
*
*      @author Alexandra Conache                      
*/
Link* game_get_link(Game* game, Id id);
/**
*      @brief Returns the object the player is holding in their inventory
*                                   
*      @param: structure Game from file game.c
*
*      @author Alexandra Conache                      
*/
Object* game_get_player_object(Game* game, Player* player);

/**
*      @brief Returns the field description from Game's structure
*                                   
*      @param: structure Game from file game.c
*
*      @author Alexandra Conache                      
*/
char* game_get_description(Game* game);

/**
 *      @brief Return the name of one of player's objects
 *  
 *      @param structure Game and the object's id
 * 
 *      @author Alexandra Conache
 */
char* game_get_player_object_name(Game* game, Id id);
#endif
