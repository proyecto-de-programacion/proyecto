#ifndef INVENTORY_H
#define INVENTORY_H

#include "types.h"
#include "set.h"
/* maxObjects is written that way because it's the name we gave it in the 
Inventorie's structure */
typedef struct _Inventory Inventory;

/**
 *  @brief Creates the inventory
 *
 *  inventory_create Reserves enough memory to create the inventory
 *                   it assigns it an id, a name and a location
 *                   as well as making sure everything is working
 *                   properly
 *
 *  @date 01/03/2019
 *  @authors Sara Erika Catana
 *
 *
 *
 */
Inventory* inventory_create();
/**
 *  @brief Destroys the inventory by freeing the allocated memory
 *
 *  inventory_destroy Frees the memory we reserved with the function inventory_create
 *                    it also assigns it a NULL value to tie up loose ends
 *                    furthermore it has a control code to prevent possible
 *                    errors
 *
 *  @date 01/03/2019
 *  @authors Sara Erika Catana
 *
 *  @param inventory the inventory created that's going to be destroyed
 *
 */
STATUS inventory_destroy(Inventory* inventory);
/**
 *  @brief Returns the inventorie's object's identifiers
 *
 *  
 *  @date 01/03/2019
 *  @authors Sara Erika Catana
 *
 *  @param inventory is the inventory we created
 *  @param inventory is the player's inventory
 */
Set * inventory_get_set(Inventory* inventory);
/**
 *  @brief Returns the inventorie's max object's 
 *
 *  inventory_get_maxObjects           Is a function that assesses whether the inventory exists and
 *                                     it calls the inventorie's structure to get its max objects
 *
 *  @date 01/03/2019
 *  @authors Sara Erika Catana
 *
 *  @param inventory is the inventory we created
 *  @param inventory is the player's inventory
 */
int inventory_get_maxObjects(Inventory* inventory);
/**
 *  @brief Sets the set
 *
 *
 *
 *  @date 02/03/2019
 *  @authors Sara Erika Catana
 *
 *  @param inventory is the inventory we created
 *  @param 
 */
STATUS inventory_set_set(Inventory* inventory, Id id);
/**
 *  @brief Set the maxObjects value
 *
 *  inventory_set_maxObjects 
 *
 *
 *  @date 02/03/2019
 *  @authors Sara Erika Catana
 *
 *  @param inventory is the inventory we created
 *  @param 
 */
STATUS inventory_set_maxObjects(Inventory* inventory, int new_size);
/**
 *  @brief Prints the inventory
 *
 *  inventory_print     Prints the Inventory structure
 *
 *  @date 07/04/2019
 *  @author Alex Conache
 *
 *  @param inventory is the pointer assigned to the Inventory TAD
 *         
 */
STATUS inventory_print(Inventory* inventory);
/**
 *  @brief Deletes an object
 *
 *  inventory_delete_object     Deletes the objects with the same ID as the one given
 *
 *  @date 07/04/2019
 *  @author Alex Conache
 *
 *  @param inventory is the pointer assigned to the Inventory TAD
 *         object_id is the ID of the objects which is gonna get deleted
 */
STATUS inventory_delete_object(Inventory *inventory , Id object_id);
/**
 *  @brief Adds a new object
 *
 *  inventory_add_object     Adds a new object to the inventory
 *
 *  @date 07/04/2019
 *  @author Alex Conache
 *
 *  @param inventory is the pointer assigned to the Inventory TAD
 *         object_id is the ID of the objects which is gonna get deleted
 */
STATUS inventory_add_object(Inventory *inventory ,Id object_id);
/**
 *  @brief Asks if the object with the provided id is in the inventory
 *
 *  
 *  @date 07/04/2019
 *  @author Alex Conache
 *
 *  @param inventory is the pointer assigned to the Inventory TAD
 *         new_size is the new value
 */
BOOL inventory_ask_id(Inventory* inventory, Id object_id);
#endif
