/**
 * @brief It implements the command interpreter
 *
 * @file command.h
 * @author Profesores PPROG
 * @version 1.0
 * @date 19-12-2014
 * @copyright GNU Public License
 */

#ifndef COMMAND_H
#define COMMAND_H

#include "types.h"
/* !<  Enumeration of the commands and their values  */

#define MAX_NAME 32

typedef enum Enum_Command {
  NO_CMD = -1,  
  UNKNOWN, /* 0 */
  EXIT,	/* 1 */
  NEXT,	/* 2 */
  BACK,	/* 3 */
  LEFT,	/* 4 */
  RIGHT,/* 5 */
  ROLL,	/* 6 */
  PICKUP,/* 7 */
  DROP,	/* 8 */
  MOVE,	/* 9 */
  INSPECT/* 10 */
  }Enum_command;

typedef struct _Command Command;


/**
*      @brief   Creation of the command
*                              
*           
*      @param -
*      @date  11/03/2019 
*      @authors AlexandraConache & CiroAlonso                       
*/
Command *command_create();

/**
*      @brief Destruction of the command
*               
*           
*      @param The command we want to destroy
*      @date  11/03/2019 
*      @authors AlexandraConache & CiroAlonso                       
*/
void command_destroy(Command *pc);

/**
*      @brief Get the name
*                              
*           
*      @param  The command inquired about
*      @date  11/03/2019 
*      @authors AlexandraConache & CiroAlonso                       
*/
char *command_get_name(Command *pc);

/**
*      @brief Get the command
*                              
*            
*      @param The command inquired about
*      @date  11/03/2019 
*      @authors AlexandraConache & CiroAlonso                       
*/
Enum_command command_get_command(Command *pc);

/**
*      @brief Gets the user input of the commands
*                              
*      In charge of reading the value of the users input of the commands 
*           
*      @param The character we imput
*      @date  11/03/2019 
*      @authors AlexandraConache & CiroAlonso                       
*/


/**
*      @brief Gets the user input of the commands
*                              
*           
*      @param The character we imput
*      @date  4/04/2019 
*      @authors AlexandraConache                       
*/
STATUS command_get_user_input(Command *pc);

/**
*      @brief Set the command
*                              
*            
*      @param Command structure and the command we want to set
*      @date  11/03/2019 
*      @authors AlexandraConache & CiroAlonso                       
*/
Command *command_set_command(Command *pc, Enum_command cmd);

/**
*      @brief Set the name
*                              
*           
*      @param The command we want to change and the name we imput
*      @date  11/03/2019 
*      @authors AlexandraConache & CiroAlonso                       
*/
Command *command_set_name(Command *pc, const char *name);

#endif
