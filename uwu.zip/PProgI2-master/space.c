/**
 *  @brief An implementation to use 'space' data type
 *
 *  Here all functions related to 'space' data types are implemented as well as the structure Object
 *
 *  @file space.c
 *  @version 1.0
 *  @date 17/02/2019
 *  @authors Alonso Aquino Ciro, Conache Alexandra
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "space.h"
#include "link.h"
/**
 *   @brief Space structure
 *
 *   Stores relevant information about the space the game is held in
 *
 */

struct _Space {
  Id id;                      /*!< The ID the space has assigned */
  char name[WORD_SIZE + 1];   /*!< The name we can assign to the space */
  Link* north;                   /*!< The upper part of the space */
  Link* south;                   /*!< The downwards part of the space */
  Link* east;                    /*!< The right part of the space */
  Link* west;                    /*!< The left part of te space */
  Set *objects;               /*!< What object iss currently on the space */
  char *gdesc[3][7];             /*!< campo gdesc*/
};



/* It creates a space */
Space* space_create(Id id) {
  Space *newSpace = NULL;

  if (id == NO_ID)
    return NULL;

  newSpace = (Space *)malloc(sizeof(Space));

  if (newSpace == NULL) {
    return NULL;
  }
  newSpace->id = id;

  newSpace->name[0] = '\0';

  newSpace->north = link_create();
  newSpace->south = link_create();
  newSpace->east = link_create();
  newSpace->west = link_create();
  newSpace->objects = set_create();
 
  return newSpace;
}

/**
 *  @brief Destroys the space by freeing the allocated memory
 *
 *  space_destroy Frees the memory we reserved with the function space_create
 *                 it also assigns it a NULL value to tie up loose ends
 *                 furthermore it has a control code to prevent possible
 *                 errors
 *
 *  @date 17/02/2019
 *  @authors Alonso Aquino Ciro, Conache Alexandra
 *
 *  @param space the space created that's going to be destroyed
 *
 */



STATUS space_destroy(Space* space) {
  if (!space) {
    return ERROR;
  }
  set_destroy(space->objects);
  free(space);
  space=NULL;

  return OK;
}


/* It destroyes the memory allocated to the prviously created space, thus destroying it */
STATUS space_set_name(Space* space, char* name) {

  /* This code makes sure a player exists and if it does it has a name */

  if (!space || !name) {
    return ERROR;
  }

  if (!strcpy(space->name, name)) {
    return ERROR;
  }

  return OK;
}



/* It assigns the space another space in the north direction */
STATUS space_set_north(Space* space, Link *link) {
  if (!space || link == NULL) {
    return ERROR;
  }
  space->north = link;
  return OK;
}



/* It assigns the space another space in the south direction */
STATUS space_set_south(Space* space, Link *link) {
  if (!space || link == NULL) {
    return ERROR;
  }
  space->south = link;
  return OK;
}






/* It assigns the space another space in the east direction */
STATUS space_set_east(Space* space, Link *link) {
  if (!space || link == NULL) {
    return ERROR;
  }
  space->east = link;
  return OK;
}



/* It assigns the space another space in the west direction */
STATUS space_set_west(Space* space, Link *link) {
  if (!space || link == NULL) {
    return ERROR;
  }
  space->west = link;
  return OK;
}



/* Makes sure the space exists and assign it an object */
STATUS space_set_object(Space* space, Id id) {
  
  if (!space || id == NO_ID) {
    return ERROR;
  }
  
  return set_add(space->objects,id);
}



/* It returns the name assigned to the space */
const char * space_get_name(Space* space) {
  if (!space) {
    return NULL;
  }
  return space->name;
}



/* It returns the space's id */
Id space_get_id(Space* space) {
  if (!space) {
    return NO_ID;
  }
  return space->id;
}


/* It returns wether the space has another linked north of it */
Link* space_get_north(Space* space) {
  if (!space) {
    return NULL;
  }
  return space->north;
}


 /* It returns wether the space has another linked south of it */
Link space_get_south(Space* space) {
  if (!space) {
    return NULL;
  }
  return space->south;
}


/* It returns wether the space has another linked east of it */
Link space_get_east(Space* space) {
  if (!space) {
    return NULL;
  }
  return space->east;
}



/* It returns wether the space has another linked west of it */
Link space_get_west(Space* space) {
  if (!space) {
    return NULL;
  }
  return space->west;
}


 /* It deletes the object form set if is in there returns OK if done, else ERROR  */
STATUS space_get_object(Space* space, Id id) {
  if (!space || id == NO_ID) {
    return ERROR;
  }
  if(set_Id_inArray(space->objects, id)==TRUE){
    set_del(space->objects, id);
    return OK;
  }
  
  return ERROR;  
}



 /* It prints the space on screen */
STATUS space_print(Space* space) {
  Link idaux = NULL;
  if (!space) {
    return ERROR;
  }

  fprintf(stdout, "--> Space (Id: %ld; Name: %s)\n", space->id, space->name);

  idaux = space_get_north(space);
  if (NULL != idaux) {
      fprintf(stdout, "---> North link: \n");
      link_print(idaux);
  } else {
    fprintf(stdout, "---> No north link.\n");
  }

  idaux = space_get_south(space);
  if (NULL != idaux) {
    fprintf(stdout, "---> South link: \n");
    link_print(idaux);
  } else {
    fprintf(stdout, "---> No south link.\n");
  }

  idaux = space_get_east(space);
  if (NULL != idaux) {
    fprintf(stdout, "---> East link: \n");
    link_print(idaux);
  } else {
    fprintf(stdout, "---> No east link.\n");
  }

  idaux = space_get_west(space);
  if (NULL != idaux) {
    fprintf(stdout, "---> West link: \n");
    link_print(idaux);
  } else {
    fprintf(stdout, "---> No west link.\n");
  }
  /* Me he cargado el print de los objects*/
  return OK;
}


STATUS space_set_gdesc(Space* space, char *string, int i) {
  
  if ((!space)) {
    return ERROR;
  }
  
  strcpy((char*)space->gdesc[i],string);

  
  return OK;
}

char* space_get_gdesc1(Space* space) {
  if (!space) {
    return ERROR;
  }
  return (char*)space->gdesc[0];
}

char* space_get_gdesc2(Space* space) {
  if (!space) {
    return ERROR;
  }
  return (char*)space->gdesc[1];
}

char* space_get_gdesc3(Space* space) {
  if (!space) {
    return ERROR;
  }
  return (char*)space->gdesc[2];
}


/*  Returns True if the object is in the space, false if everything else  */
BOOL space_object_is_in(Space* space, Id id){
  if(!space ){
    return FALSE;
  }
  if(set_Id_inArray(space->objects, id) == TRUE){
    return TRUE;
  }
  return FALSE;
}