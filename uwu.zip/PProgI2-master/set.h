#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "types.h"



#define TAM_ID 4

typedef struct _Set Set;


Set* set_create();


STATUS set_destroy(Set* set);


STATUS set_add(Set* set,Id id);


STATUS set_del(Set* set,Id id);


STATUS set_print(Set *set);

Id set_get_id (Set *set ,int position);

BOOL set_is_full(Set* set);
BOOL set_is_empty(Set* set);


BOOL set_Id_inArray(Set *set, Id id);


Set *set_copy(Set *ps);