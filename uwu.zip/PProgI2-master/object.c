/**
 *  @brief An implementation to use 'object' data type
 *
 *  Here all functions related to 'object' data types are implemented as well as the structure Object
 *
 *  @file object.c
 *  @version 1.0
 *  @date 17/02/2019
 *  @authors Alonso Aquino Ciro, Conache Alexandra
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "object.h"


/**
 *   @brief Object structure
 *
 *   Stores relevant information about the object players use to play the game
 *
 */


struct _Object {
  Id id;                     /*!< The ID the object has assigned */
  char name[WORD_SIZE + 1];  /*!< The name we can assign to the object */
  char descripcion[WORD_SIZE + 1];
 };


/* It creates an object */
Object* object_create(Id id) {

  Object *newObject = NULL;

  newObject = (Object *) malloc(sizeof (Object)+1);

  if (newObject == NULL) {
    return NULL;
  }
  newObject->id = id;

  newObject->name[0] = '\0';
  newObject->descripcion[0] = '\0';

  return newObject;
  }



/* It destroyes the memory allocated to the prviously created object, thus destroying it */
STATUS object_destroy(Object* object) {
    if (!object) {
      return ERROR;
    }

    free(object);

  return OK;
}

/* It returns the object's id */
Id object_get_id(Object* object) {
  if (!object) {
    return NO_ID;
  }
  return object->id;
}


/* It assigns a name to the object */
STATUS object_set_name(Object* object, char* name) {

  /* This code makes sure an object exists and if it does it has a name */

  if (!object || !name) {
    return ERROR;
  }

  if (!strcpy(object->name, name)) {
    return ERROR;
  }

  return OK;
}


/* It returns the name assigned to the object */
char * object_get_name(Object* object) {
  if (!object) {
    return NULL;
  }
  return object->name;
}


STATUS object_set_descripcion(Object* object, char* descripcion) {

  /* This code makes sure an object exists and if it does it has a name */

  if (!object || !descripcion) {
    return ERROR;
  }

  if (!strcpy(object->descripcion, descripcion)) {
    return ERROR;
  }

  return OK;
}


char * object_get_descripcion(Object* object) {
  if (!object) {
    return NULL;
  }
  return object->descripcion;
}


/* It prints the object on screen */
STATUS object_print(Object* object) {

  if (!object) {
    return ERROR;
  }

  fprintf(stdout, "--> Object (Id: %ld; Name: %s; Descripcion_ %s)\n", object->id, object->name,object->descripcion);

  return OK;
}

